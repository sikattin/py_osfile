# -*- coding: utf-8 -*-
import unittest
import zipfile
from osfile import fileope

TESTDIR_PATH = '/tmp/test/test1/test2/test3'
TESTDIR_BASE = '/tmp/test'
class TestFileope(unittest.TestCase):
    """fileope module test class."""

    def setUp(self):
        """entering process."""
        if not fileope.dir_exists(path=TESTDIR_PATH):
            fileope.make_dirs(path=TESTDIR_PATH)

    def tearDown(self):
        """exiting process"""
        pass

    def test_zip_data(self):
        """zip_data function test method."""
        fileope.zip_data(file_path=TESTDIR_PATH)
        self.assertTrue(zipfile.is_zipfile("{}.zip".format(TESTDIR_BASE)))


if __name__ == '__main__':
    unittest.main()